
import socket,pickle,os
from threading import Thread
import time
from colorama import init, Fore, Back, Style
init(autoreset=True)

s = socket.socket()

hostn = raw_input ( Fore.WHITE 
                  + Back.BLUE 
                  + "Enter the i.p. address that you would like to connect to: \n")
#print (hostn)

HOST = 'localhost'
for hn in hostn:
    if re.match('\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$', hn) is not None:
        HOST = hostn
    else:
        print(" Host set to localhost. \n")
    
#print HOST
username = raw_input(Fore.MAGENTA + Back.YELLOW + "Enter your username: ")
s.connect(( HOST, 2000))


def receive():
    while True:
        data = s.recv(81926).decode()
        os.system("clear")
        print ( Fore.WHITE 
              + Back.BLUE 
              + data).strip()
       # for item in data:
        #    print(item)

Thread(target=receive).start()

s.send(username.encode())
time.sleep(0.5)
while True:
    msg = raw_input ( Fore.MAGENTA 
                    + Back.YELLOW 
                    + ">> ")
    if msg is "!q":
       break
    s.send(msg.encode())
    time.sleep(0.5)


