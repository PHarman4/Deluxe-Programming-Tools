'''
Network Monitoring Tool
Gets the ip address, mac address,
device manufacturer, and guesses the operating system

Written for CS498G at Hood College
Joshua C., Grant N., Phil H.

Dependencies:
Must run python command with root privlages for nmap

Must have nmap command line utility installed.
Must have arp-scan command line utility installed when on Linux system.
Must have netifaces installed for python.

'''

import subprocess
import re
import platform
import netifaces

def get_ips():
	# our first argument to run, arp -a
	# this gets us a list of IP addresses on the same network
	myplatform = platform.system()
	interfaces = netifaces.interfaces()
	arg2 = ""

	if(myplatform == 'Linux'):
		scan_type = raw_input("Would you like to look for devices on your local wired or wireless network?\n"
                             +"Enter 'e' for wired or 'w' for wireless: ")
		if(scan_type == 'w'):
			for x in interfaces:
				if(x.startswith('w')):
					arg2 = x
			if(arg2 == ""):
				print "Could not find wireless interface, scanning " + interfaces[1] + "."
				arg2 = interfaces[1]			
		elif(scan_type == 'e'):
			for x in interfaces:
				if(x.startswith('e')):
					arg2 = x
			if(arg2 == ""):
				print "Could not find wired interface, scanning " + interfaces[1] + "."
				arg2 = interfaces[1]
		arparg = ['arp-scan', '--interface='+arg2, '--localnet']
	else:
		arparg = ['arp', '-a']
	arpng = subprocess.Popen((arparg), stdout=subprocess.PIPE)
	ipout = arpng.communicate()[0]

	# initalize an empty list to fill with just IP addresses
	# compiles our regular expression to check each lines against
	# and then add that line to our list of IPs if it is a match
	iplist = []
	regexp = re.compile(r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}')
	# use a loop and a regex to extract just the IP addresses
	for lines in ipout.splitlines():
		if regexp.search(lines):
			iplist.append(re.search(r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}', lines).group())
	return iplist

def device_info(iplist):
	device_list = []
	current_ip = ""
	current_mac = ""
	current_manuf = ""
	current_os = ""

	for addr in iplist:
		args = ['nmap', '-O', '-v', addr]
		nmap = subprocess.Popen((args), stdout=subprocess.PIPE)
		nmout = nmap.communicate()[0]
		current_ip = addr
		for lns in nmout.splitlines():
			if(lns.startswith("MAC")):
				current_mac = lns.split("(")[0]
				current_manuf = lns[lns.find("(")+1:lns.find(")")]
			if lns.startswith("Aggressive OS guesses:"):
				current_os = lns
		if current_os == "":
				current_os = 'Too many fingerprints match this host to give specific OS details'
		print '\n------ Device Info ------'
		print 'IP Address: ' + current_ip
		print 'Mac Address: ' + current_mac
		print 'Device Manufacturer: ' + current_manuf
		print 'Operating System Guesses: ' + current_os + '\n'

if __name__ == '__main__':
		ips = get_ips()
		device_info(ips)

