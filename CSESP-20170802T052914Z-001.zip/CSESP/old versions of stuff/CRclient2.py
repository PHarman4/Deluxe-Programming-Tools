import asynchat
import asyncore
import socket
import threading
 
#class ChatClientRead(asynchat.async_chat):
class ChatClient(asynchat.async_chat): 
    
    def __init__(self, host, port):
        asynchat.async_chat.__init__(self)
        self.create_socket(socket.AF_INET, socket.SOCK_STREAM)
        self.connect((host, port))
        self.set_terminator('\n')
        self.buffer = []

    def collect_incoming_data(self, data):
        self.buffer.append(data)
 
    def found_terminator(self):
        msg = ''.join(self.buffer)
        print 'Received:', msg
        self.buffer = []
""" 
    def collect_incoming_data(self, data):
        pass
 
    def found_terminator(self):
        pass
"""

"""
"""
 
client = ChatClient('localhost', 5050)
#client = ChatClientRead('localhost', 5050)
print 'Listening on localhost:5050 \n'
asyncore.loop()

comm = threading.Thread(target=asyncore.loop)
comm.daemon = True
comm.start()
 
while True:
    msg = raw_input('Say:> ')
    client.push(msg + '\n')

# # # # # # # # # #  # # # # # # # # # # # # # # # # # # # # #  
#class ChatClientSend(asynchat.async_chat):
#class ChatClient(asynchat.async_chat):
"""
    def __init__(self, host, port):
        asynchat.async_chat.__init__(self)
        self.create_socket(socket.AF_INET, socket.SOCK_STREAM)
        self.connect((host, port))
 
        self.set_terminator('\n')
        self.buffer = []
"""
""" 
    def collect_incoming_data(self, data):
        self.buffer.append(data)
 
    def found_terminator(self):
        msg = ''.join(self.buffer)
        print 'Received:', msg
        self.buffer = []
client = ChatClient('localhost', 5050)
#client = ChatClientSend('localhost', 5050)
"""
 
#print 'Listening on localhost:5050'
#asyncore.loop()






